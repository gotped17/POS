DROP TABLE book_authors;
DROP TABLE book_genres;
DROP TABLE authors;
DROP TABLE books;
DROP TABLE genres;
DROP TABLE publishers;
